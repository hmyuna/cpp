#include<cstdio>
int main(){char s[]="#include<cstdio>%cint main(){char s[]=%c%s%c;printf(s,10,34,s,34);}";printf(s,10,34,s,34);}